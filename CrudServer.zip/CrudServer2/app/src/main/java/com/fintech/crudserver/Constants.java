package com.fintech.crudserver;

public class Constants {
    public static final String URL_API = "http://vsga.zulhaydarakbar.com";
    public static final String TOKEN = "tokenAlfin"; // Isi sendiri
}
